<template>
  <img class="logo" src="@/static/ath_logo.png" alt="Aussie Tiny Houses Logo" />
</template>

<script lang="ts">
import Vue from 'vue'

export default Vue.extend({})
</script>

<style scoped>
.logo {
  @apply w-full h-full;
}
</style>
