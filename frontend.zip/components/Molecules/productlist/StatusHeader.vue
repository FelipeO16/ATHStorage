<template>
  <div class="status-header">ATH - Products Status</div>
</template>

<script lang="ts">
import Vue from 'vue'

export default Vue.extend({})
</script>

<style scoped>
.status-header {
  @apply w-full h-10 flex flex-col items-center justify-center gap-4 bg-royal-blue-500  text-french-gray-300 rounded-t-lg tracking-widest select-none;
}
</style>
