import Vue from 'vue'
import QrcodeVue from 'qrcode.vue'
Vue.use(QrcodeVue)