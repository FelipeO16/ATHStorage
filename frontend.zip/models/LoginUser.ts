export interface LoginUser {
  [key: string]: string
}
