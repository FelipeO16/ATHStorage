export interface NewUserFinish {
    id: number
    key: string
    email: string
    name: string
    password: string
    passwordConfirmation: string
}