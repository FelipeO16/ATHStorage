export interface Categories {
  [key: string]: any
}
