export interface CartItem {
  id: number
  code: string
  suplier: string
  description: string
  quantity: number
}
