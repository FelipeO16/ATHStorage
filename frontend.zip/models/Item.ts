export interface Item {
  id: number
  code: string
  suplier: string
  description: string
  class: number
  price: number
  storage: number
  min: number
  max: number
  place: number
  status: string
}
