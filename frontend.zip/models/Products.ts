export interface Products {
  [key: string]: any
}
